﻿using comb;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;


var Game = new Game();
Card card = new Card();
var tableCards = card.TableCards;
card.InitializeCards();
var p1 = new Player()
{
Name = "John Doe",
Points = 1500m,
PlayerCards = new List<Card>()
};
var p2 = new Player()
{
    Name = "Jason Statham",
    Points = 1500m,
    PlayerCards = new List<Card>()
};


p1.PlayerCards.Add(card.Cards[2]);
p1.PlayerCards.Add(card.Cards[4]);

foreach (var c in p1.PlayerCards)
   Console.WriteLine($"Player 1 Card: {c.ToString()}");

Console.WriteLine();

tableCards.Add(card.Cards[2]);
tableCards.Add(card.Cards[3]);
tableCards.Add(card.Cards[5]);
tableCards.Add(card.Cards[6]);
tableCards.Add(card.Cards[7]);

foreach(var c in tableCards)
    Console.WriteLine(c.ToString());
Console.WriteLine();


Game.CheckCombinations(p1, tableCards);
