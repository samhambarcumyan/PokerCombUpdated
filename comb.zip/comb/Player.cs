﻿namespace comb;

public class Player()
{
    public List<Card> PlayerCards { get; set; } = new List<Card>();
    public decimal Points { get; set; } = 1500m;
    public required string Name { get; set; }
}
