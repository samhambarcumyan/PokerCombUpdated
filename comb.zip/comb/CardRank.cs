﻿using System;
using System.Collections.Generic;
using System.Text;

namespace comb
{
    public enum Ranks
    {
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King,
        Ace
    }

    
}
